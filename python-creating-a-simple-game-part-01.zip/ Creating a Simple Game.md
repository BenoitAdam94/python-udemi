# Python: Creating a Simple Game
This is a short course of building Pong in Python.

## Python Simple Game
Python Simple Game

### Python - Creating a Simple Game, intro
Python miniseries covering creation of a pong-style game.  In this video we get Python and Pygame installed and write a test script to verify that Pygame is working.

### Python - Creating a Simple Game, pt1
We begin work on the pong game.  The script is filled out with game settings, some functions are "skeletoned" into place, and the game loop is created.

### Python - Creating a Simple Game, pt2
This video covers the creation of the Vector2 and Actor classes.  The Vector2 class contains functionality that allows it to act as a numeric type.

### Python - Creating a Simple Game, pt3
This video focuses on the creation of a Ball class.  This class contains functionality allowing the ball to bounce and also handles "launching" the ball.

### Python - Creating a Simple Game, pt4
This video adds the Player class to the game.  The collision detection between ball and paddles is also covered in this video.

### Python - Creating a Simple Game, pt5
Font rendering discussed and the surfaces are set up to handle screen rendering.  Some scope issues addressed when re-rendering the text surface from within a class.

